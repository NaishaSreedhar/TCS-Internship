package com.pages.Supplier;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SupplierLink {

	WebDriver driver;


	@FindBy(xpath = "//a[@aria-controls='toursmodule']")
	private WebElement toursLink;

	@FindBy(xpath = "//div[@id='toursmodule']/nav/a")
	private WebElement toursLinksub;

	@FindBy(xpath = "//a[text()='Manage Tours']")
	private WebElement manageTours;
	
	@FindBy(xpath="(//a[@href='https://phptravels.net/api/supplier/bookings'])[2]")
	private WebElement bookings;
	
	public SupplierLink(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	

	public void toursLink() throws InterruptedException {
		toursLink.click();
			}

	public void toursLink1() throws InterruptedException {
		toursLinksub.click();
	
	}

	public void manageTours() throws InterruptedException {
		manageTours.click();

	}
   public void Booking()
   {
	   bookings.click();
   }
}
