package com.pages.Supplier;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SupplierDashboardView 
{

	WebDriver driver;
	
	
	
	
	@FindBy(xpath = "//div[text()='Sales overview & summary']")
	private WebElement TextDashboard;
	
	public SupplierDashboardView(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}
	

	public boolean isSalesTextPresent() {
		boolean textsales = TextDashboard.isDisplayed();

		if (textsales == true) {
			String HeadText = TextDashboard.getText();

			return (HeadText.equals("Sales overview & summary"));

		}

		return false;
	}
}