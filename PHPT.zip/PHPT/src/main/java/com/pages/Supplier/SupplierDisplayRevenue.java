package com.pages.Supplier;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SupplierDisplayRevenue {
	
WebDriver driver;

@FindBy(xpath="//h2[text()='Revenue Breakdown 2023']")
private WebElement RevenueBreakDown;

public SupplierDisplayRevenue(WebDriver driver)
{
	 this.driver = driver;
	 PageFactory.initElements(driver,this);
	
}

	

	
	public boolean isRevenuePresent()
	{
		boolean valuerevenue =RevenueBreakDown.isDisplayed();
		
		if( valuerevenue == true )
		{
			String headingRevenue=RevenueBreakDown.getText();
			
			return ( headingRevenue.equals("Revenue Breakdown 2023"));
			
		}
		
		return false;
	}
}
