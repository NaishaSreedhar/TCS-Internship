package com.pages.Supplier;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class SupplierLogout {

WebDriver driver;

@FindBy(xpath="//i[text()='person']")
private WebElement icon;

@FindBy(xpath="//div[text()='Logout']")
private WebElement logout;

 public SupplierLogout(WebDriver driver)
 {
	 this.driver = driver;
	 PageFactory.initElements(driver,this);
	
 }
public void ClickIcon()
{
	icon.click();
}
 public void Logout()
 {
 logout.click();
}   
	
}
