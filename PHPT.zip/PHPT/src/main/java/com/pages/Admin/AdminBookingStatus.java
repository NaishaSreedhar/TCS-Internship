package com.pages.Admin;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class AdminBookingStatus {

	WebDriver driver;

	@FindBy(xpath = "//div[text()='Pending Bookings']")
	private WebElement pendingBooking;

	@FindBy(xpath = "(//select[@id='booking_status'])[1]")
	private WebElement pending;

	@FindBy(xpath = "//div[text()='Confrimed Bookings']/preceding-sibling::div")
	private WebElement confirmCount;

	@FindBy(xpath = "//div[text()='Pending Bookings']/preceding-sibling::div")
	private WebElement pendingCount;

	public AdminBookingStatus(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	public void ClickPendBooking() {
		pendingBooking.click();
	}

	public void ChangeStatus() {
		Select dropdown = new Select(pending);
		dropdown.selectByIndex(1);

	}

	public String CountConfirm() {
		return confirmCount.getText();
	}

	public String CountPending() {
		return pendingCount.getText();
	}

}
