package com.pages.Admin;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AdminDeleteRecord {

	
	WebDriver driver;
	
	@FindBy(xpath="//div[text()='Cancelled Bookings']")
	private WebElement cancelledB;
	
	@FindBy(xpath="//button[@class='btn btn-danger mdc-ripple-upgraded']")
	private WebElement delete;
	
	 public AdminDeleteRecord(WebDriver driver)
	 {
		 this.driver = driver;
		 PageFactory.initElements(driver,this);
		
	 }
	 
	 public void CancelBooking()
	 {
		 cancelledB.click();
	 }
	public void DeleteStatus()
	{
		delete.click();
	}
}
