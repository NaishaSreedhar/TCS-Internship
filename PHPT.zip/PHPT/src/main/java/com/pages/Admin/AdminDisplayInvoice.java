package com.pages.Admin;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AdminDisplayInvoice {

	 WebDriver driver;
	
	@FindBy(xpath="//a[text()='Bookings']")
	private WebElement booking;
	
	@FindBy(xpath="//div[text()='Paid Bookings']")
	private WebElement paid;
	
	
	@FindBy(xpath="//a[@href='https://phptravels.net/api/../hotels/booking/invoice/3215/5']")
	private WebElement invoice;
	
	 public AdminDisplayInvoice(WebDriver driver)
	 {
		 this.driver = driver;
		 PageFactory.initElements(driver,this);
		
	 }
	 
	 public void ClickBooking()
	 {
		 booking.click();
	 }
	 public void Clickpaid()
	 {
		 paid.click();
	 }
	 public void ClickInvoice()
	 {
		 invoice.click();
	 }
}
