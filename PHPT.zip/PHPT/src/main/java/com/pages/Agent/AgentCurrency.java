package com.pages.Agent;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AgentCurrency {
   
	
	WebDriver driver;
	
	@FindBy(xpath="//button[@id='currency']")
	private WebElement Dropdown;
	
	@FindBy(xpath="//a[text()=' INR']")
	private WebElement indianrupee;

	 public AgentCurrency(WebDriver driver)
	 {
		 this.driver = driver;
		 PageFactory.initElements(driver,this);
		
	 }
	 
	 
	 public void clickDropDown()
	 {
		Dropdown.click();
		 
	 }
	 public void Clickrupee()
	 {
		 indianrupee.click();
	 }
	
}
