package com.pages.Agent;

import java.util.List;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AgentSearchHotel<WebElements> {

	WebDriver driver;
	
	
	
	@FindBy(xpath="//a[text()='Hotels']")
	private WebElement hotels;
	
	@FindBy(xpath="//*[@id='select2-hotels_city-container' and @role='textbox']")
	private WebElement searchcityname;
	
	@FindBy(xpath = "(//input[@role='searchbox'])[1]")
	private WebElement keyword;
	
	@FindBy(css=".select2-results__option")
	 List<WebElement> options;
	
	@FindBy(xpath="//button[@id='submit']")
	private WebElement search;
	
	

	 public AgentSearchHotel(WebDriver driver)
	 {
		 this.driver = driver;
		 PageFactory.initElements(driver,this);
		
	 }
	 public void Clickhotels()
	 {
		 hotels.click();
		 
	 }
	 public void clicksearchcity()
	 {
		 searchcityname.click();
	 }
	public void SearchCity(String Strcity)
	{ 
		keyword.sendKeys(Strcity);
		
	}
	public void SelectOption()
	
	{
	for(WebElement option :options)
	{
		if(option.getText().equalsIgnoreCase("Singapore,Singapore"))
				{
			option.click();
			break;
				}
	}
	}
	public void Search()
	{
		search.click();
	}
}
