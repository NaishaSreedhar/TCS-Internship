package com.pages.Agent;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AgentLinks {
	
	WebDriver driver;
	
	@FindBy(xpath="(//div[@class='dropdown']/button)[2]")
	private WebElement accdrop;
	
	@FindBy(xpath="//a[text()=' Dashboard']")
	private WebElement dashb;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/bookings']/i")
	private WebElement booking;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/add_funds']/i")
	private WebElement addfund;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/profile']/i")
	private WebElement myprofile;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/logout']/i")
	private WebElement logout;
	
	
	
	 public AgentLinks(WebDriver driver)
	 {
		 this.driver = driver;
		 PageFactory.initElements(driver,this);
		
	 }
	 public void clickdrop()
	 {
		 accdrop.click();
	 }
	 public void clickDash()
	 {
		 dashb.click();
	 }
	 public boolean clickBooking()
	 {
		booking.click();
		return false; 
	 }
	
	 public boolean clickAddfund()
	 {
		 
		 addfund.click();
		return false;
	 }
	public boolean clickMyprofile()
	{
		myprofile.click();
		return false;
	}
	public boolean ClickLogout()
	{
		logout.click();
		return false;
	}
	
}
