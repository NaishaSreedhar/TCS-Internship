package com.pages.Agent;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AgentNavLink {

	
	WebDriver driver;
	
	@FindBy(xpath="//div[@class='logo']/a")
	private WebElement home;
	
	@FindBy(xpath="//a[text()='Hotels']")
	private WebElement hotels;
	
	@FindBy(xpath="//a[text()='flights']")
	private WebElement flights;
	
	@FindBy(xpath="//a[text()='Tours']")
	private WebElement tours;
		
	@FindBy(xpath="//a[text()='visa']")
	private WebElement visa;
	
	@FindBy(xpath="//a[text()='Blog']")
	private WebElement blog;
	
	@FindBy(xpath="//a[text()='Offers']")
	private WebElement offers;
	

	 public AgentNavLink(WebDriver driver)
	 {
		 this.driver = driver;
		 PageFactory.initElements(driver,this);
		
	 }
	 public boolean clickHome()
	 {
		 
		home.click();
		return false;
	 }
	 public boolean clickHotels()
	 {
		 hotels.click();
		 return false;
	 }
	 public boolean clickFlights()
	 {
		 flights.click();
		 return false;
	 }
	 public boolean clickTours()
	 {
		 tours.click();
		 return false;
	 }
	 public boolean clickVisa()
	 {
		 visa.click();
		 return false;
	 }
	 public boolean clickBlog()
	 {
		 blog.click();
		 return false;
	 }
	 public boolean clickOffers()
	 {
		 offers.click();
		 return false;
	 }
}
