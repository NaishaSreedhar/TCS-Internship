package com.pages.Base;

import java.io.FileInputStream;


import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class TestBase {

	public static WebDriver driver;
	
	
	public static Properties prop=null;

	@BeforeTest
	public void onSetup() throws Exception 
	{
		prop=new Properties();
		FileInputStream pFile=new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\config.properties");
	    prop.load(pFile);
	    ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
    	driver=new ChromeDriver(options);
	   
	    driver.get(prop.getProperty("url1"));
	    driver.manage().window().maximize();
	    Thread.sleep(2000);}
	
   @AfterTest
	public void closeBrowser() throws Exception 
	{
		Thread.sleep(2000);
		driver.quit();
	}
	
	
	
	
	
}
