package com.pages.Customer;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CustomerUpdateAdd {

	WebDriver driver;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/profile']/i")
	private WebElement Myprofile;
	
	@FindBy(xpath="//input[@name='address1']")
	private WebElement AddOne;
	
	@FindBy(xpath="//input[@name='address2']")
	private WebElement AddTwo;
	
	@FindBy(xpath="//button[text()='Update Profile']")
	private WebElement Update;
	
	public CustomerUpdateAdd(WebDriver driver)
	 {
		 this.driver = driver;
		 PageFactory.initElements(driver,this);
		
	 }
	public void ClickMyProfile()
	{
		Myprofile.click();
	}
	public void EnterAddOne(String StrAone)
	{
		AddOne.clear();
		AddOne.sendKeys(StrAone);
	}
	public void EnterAddTwo(String StrAtwo)
	{
		AddTwo.clear();
		AddTwo.sendKeys(StrAtwo);
	}
	public void ClickUpdate()
	{
		Update.click();
	}
	
}
