package com.pages.Customer;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CustomerDisplayVoucher {

	
	WebDriver driver;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/bookings']/i")
	private WebElement booking;
	
	@FindBy(xpath="(//div[@class='table-content']/a)[1]")
	private WebElement viewVoucher;
	 public CustomerDisplayVoucher(WebDriver driver)
	 {
		 this.driver = driver;
		 PageFactory.initElements(driver,this);
		
	 }
	public void ClickBooking()
	{
		booking.click();
	}
	public void ClickViewVoucher()
	{
		viewVoucher.click();
	}
	 
}
