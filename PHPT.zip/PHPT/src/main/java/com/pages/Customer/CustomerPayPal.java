package com.pages.Customer;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CustomerPayPal {
	WebDriver driver;

	@FindBy(xpath="//a[@href='https://phptravels.net/account/add_funds']/i")
	private WebElement addfund;

	@FindBy(xpath="//input[@id='gateway_paypal']")
	private WebElement paypal;

	@FindBy(xpath="//button[@type='submit']")
	private WebElement paynow;
   
	@FindBy(xpath="//div[@class='btn-front']")
	private WebElement backtoinvoice;
	
	@FindBy(xpath="//a[text()='Yes']")
	private WebElement yes;
	
	public CustomerPayPal(WebDriver driver)
	{
		 this.driver = driver;
		 PageFactory.initElements(driver,this);
		
	}
	public void clickAddfund()
	{
		addfund.click();
	}
	public void clickpaypal()
	{
		paypal.click();
	}
	public void clickpaynow()
	{
		paynow.click();
	}
	public void Clickbacktoinvoice()
	{
		backtoinvoice.click();
	}
	public void ClickYes()
	{
		yes.click();
	}
	
	
	
	
}
