package com.pages.Customer;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CustomerLink {

	WebDriver driver;
	//a[contains(@class,'waves-effect')]
	@FindBy(xpath="//a[@href='https://phptravels.net/account/bookings']/i")
	private WebElement booking;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/add_funds']/i")
	private WebElement addfund;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/profile']/i")
	private WebElement myprofile;
	
	@FindBy(xpath="//a[@href='https://phptravels.net/account/logout']/i")
	private WebElement logout;
	
	
	
	 public CustomerLink(WebDriver driver)
	 {
		 this.driver = driver;
		 PageFactory.initElements(driver,this);
		
	 }
	
	 public boolean clickBooking()
	 {
		booking.click();
		return false; 
	 }
	
	 public boolean clickAddfund()
	 {
		 
		 addfund.click();
		return false;
	 }
	public boolean clickMyprofile()
	{
		myprofile.click();
		return false;
	}
	public boolean ClickLogout()
	{
		logout.click();
		return false;
	}
	
	
	
}
