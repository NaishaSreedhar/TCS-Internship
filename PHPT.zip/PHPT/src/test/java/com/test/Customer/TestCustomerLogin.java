package com.test.Customer;

import org.testng.annotations.Test;

import com.pages.Base.TestBase;
import com.pages.Customer.CustomerLogin;
import com.pages.utilities.ExcelUtility;

public class TestCustomerLogin extends TestBase  {

	CustomerLogin ObjLogin;
    
	@Test(priority=3)
		public void CustomerLog1() throws Exception
	{
		
		
		ObjLogin=new CustomerLogin(driver);
		driver.navigate().refresh();
		String email1 = ExcelUtility.getCellData(0, 0,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		String password1= ExcelUtility.getCellData(0, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		ObjLogin.setEmail(email1);
		ObjLogin.setPassword(password1);
		ObjLogin.clickLogin();
		
	}
	@Test(priority=2)
	public void CustomerLog2() throws Exception
	
	{
		ObjLogin=new CustomerLogin(driver);
		driver.navigate().refresh();
		String email2 = ExcelUtility.getCellData(1, 0,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		String password2 = ExcelUtility.getCellData(1, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		ObjLogin.setEmail(email2);
		ObjLogin.setPassword(password2);
		ObjLogin.clickLogin();
		Thread.sleep(2000);
	}
	@Test(priority=1)
    public void CustomerLog3() throws Exception
    {
    	ObjLogin=new CustomerLogin(driver);
		String email3 = ExcelUtility.getCellData(2, 0,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		String password3 = ExcelUtility.getCellData(2, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		ObjLogin.setEmail(email3);
		ObjLogin.setPassword(password3);
		ObjLogin.clickLogin();
		Thread.sleep(2000);
    }
	
	
}
