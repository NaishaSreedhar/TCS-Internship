package com.test.Customer;

import org.testng.annotations.Test;

import com.pages.Base.TestBase;
import com.pages.Customer.CustomerLink;
import com.pages.Customer.CustomerLogin;

public class TestCustomerLink  extends TestBase

{
	CustomerLink objCustLink;

	CustomerLogin ObjLogin;

	@Test
	public void TestCust() throws Exception
	{
		
	objCustLink =new CustomerLink(driver);
	objCustLink.clickBooking();
	
	objCustLink.clickAddfund();
	Thread.sleep(2000);
    objCustLink.clickMyprofile();
    Thread.sleep(3000);
	objCustLink.ClickLogout();
		}
}
