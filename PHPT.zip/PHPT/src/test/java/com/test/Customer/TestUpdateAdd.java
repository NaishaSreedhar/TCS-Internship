package com.test.Customer;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

import com.pages.Base.TestBase;
import com.pages.Customer.CustomerLogin;
import com.pages.Customer.CustomerUpdateAdd;
import com.pages.utilities.ExcelUtility;

public class TestUpdateAdd extends TestBase {

	CustomerUpdateAdd ObjUpdate;
	CustomerLogin ObjLogin;
	
	@Test
	
	public void UpdateTest() throws Exception
	{
		ObjUpdate=new CustomerUpdateAdd(driver);
		
		ObjUpdate.ClickMyProfile();
		String StrAone=ExcelUtility.getCellData(0, 0,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 1);
		String StrAtwo=ExcelUtility.getCellData(0, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 1);
		ObjUpdate.EnterAddOne(StrAone);
		ObjUpdate.EnterAddTwo(StrAtwo);
		Thread.sleep(3000);
		JavascriptExecutor jv = (JavascriptExecutor) driver;
		jv.executeScript("window.scrollBy(0,600)");
		Thread.sleep(2000);
		ObjUpdate.ClickUpdate();
		
		
	}
}
