package com.test.Customer;

import org.testng.annotations.Test;


import com.pages.Base.TestBase;
import com.pages.Customer.CustomerPayPal;

public class TestPaypal extends TestBase {
	
CustomerPayPal ObjCustPaypal;

@Test
public void PaypalTest() throws Exception
{
	ObjCustPaypal=new CustomerPayPal(driver);
	
	ObjCustPaypal.clickAddfund();
	ObjCustPaypal.clickpaypal();
	Thread.sleep(3000);
	ObjCustPaypal.clickpaynow();
	Thread.sleep(2000);
	Thread.sleep(2000);
	//driver.navigate().back();
	ObjCustPaypal.Clickbacktoinvoice();
	Thread.sleep(2000);
	ObjCustPaypal.ClickYes();
	
	
	
	
	
	
}


}
