package com.test.Agent;

import org.testng.annotations.Test;

import com.pages.Agent.AgentLogin;
import com.pages.Base.TestBase;
import com.pages.utilities.ExcelUtility;

public class TestAgentLogin  extends TestBase{

	
AgentLogin ObjLogin;
    
	@Test(priority=3)
		public void AgentLog1() throws Exception
	{
		
		
		ObjLogin=new AgentLogin(driver);
		driver.navigate().refresh();
		String emailagent1 = ExcelUtility.getCellData(3, 0,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		String passwordagent1= ExcelUtility.getCellData(3, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		ObjLogin.setEmail(emailagent1);
		ObjLogin.setPassword(passwordagent1);
		ObjLogin.clickLogin();
		
	}
	@Test(priority=2)
	public void AgentLog2() throws Exception
	
	{
		ObjLogin=new AgentLogin(driver);
		driver.navigate().refresh();
		String emailagent2 = ExcelUtility.getCellData(4, 0,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		String passwordagent2 = ExcelUtility.getCellData(4, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		ObjLogin.setEmail(emailagent2);
		ObjLogin.setPassword(passwordagent2);
		ObjLogin.clickLogin();
		Thread.sleep(2000);
	}
	@Test(priority=1)
    public void agentLog3() throws Exception
    {
    	ObjLogin=new AgentLogin(driver);
		String emailagent3 = ExcelUtility.getCellData(5, 0,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		String passwordagent3 = ExcelUtility.getCellData(5, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		ObjLogin.setEmail(emailagent3);
		ObjLogin.setPassword(passwordagent3);
		ObjLogin.clickLogin();
		Thread.sleep(2000);
    }
	
	
	
	
	
}
