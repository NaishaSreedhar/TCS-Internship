package com.test.Agent;

import org.testng.annotations.Test;

import com.pages.Agent.AgentNavLink;
import com.pages.Base.TestBase;

public class TestAgentNav extends TestBase
{

	AgentNavLink objAgentNav;
	@Test
	public void TestAgentnav() throws Exception
	{
		objAgentNav=new AgentNavLink(driver);
		objAgentNav.clickHome();
		Thread.sleep(2000);
		objAgentNav.clickHotels();
		Thread.sleep(2000);
		objAgentNav.clickFlights();
		Thread.sleep(2000);
		objAgentNav.clickTours();
		Thread.sleep(2000);
		objAgentNav.clickVisa();
		Thread.sleep(2000);
		objAgentNav.clickBlog();
		Thread.sleep(2000);
		//objAgentNav.clickOffers();
		//Thread.sleep(2000);
		
		
	}
	
	
}
