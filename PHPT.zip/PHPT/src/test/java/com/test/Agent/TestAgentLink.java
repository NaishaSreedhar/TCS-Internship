package com.test.Agent;

import org.testng.annotations.Test;

import com.pages.Agent.AgentLinks;
import com.pages.Base.TestBase;



public class TestAgentLink extends  TestBase {

	AgentLinks objCustLink;

	

	@Test
	public void TestCust() throws Exception
	{
		
	objCustLink =new AgentLinks(driver);
	Thread.sleep(2000);
	objCustLink.clickdrop();
	objCustLink.clickDash();
	objCustLink.clickBooking();
	objCustLink.clickAddfund();
	Thread.sleep(2000);
    objCustLink.clickMyprofile();
    Thread.sleep(3000);
	objCustLink.ClickLogout();
		}
	
	
}
