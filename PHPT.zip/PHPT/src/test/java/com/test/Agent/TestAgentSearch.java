package com.test.Agent;

import org.testng.annotations.Test;

import com.pages.Agent.AgentSearchHotel;
import com.pages.Base.TestBase;
import com.pages.utilities.ExcelUtility;

public class TestAgentSearch extends TestBase {

	
	AgentSearchHotel<?> objsearchHotel;
	@Test
	public void AgentSearchTest() throws Exception
	{
		objsearchHotel=new AgentSearchHotel<Object>(driver);
		Thread.sleep(2000);
		objsearchHotel.Clickhotels();
		Thread.sleep(2000);
		objsearchHotel.clicksearchcity();
		Thread.sleep(2000);
		String cityname=ExcelUtility.getCellData(0, 0,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 2);
		objsearchHotel.SearchCity(cityname);
		Thread.sleep(3000);
		objsearchHotel.SelectOption();
		Thread.sleep(3000);
		objsearchHotel.Search();
		Thread.sleep(2000);
		driver.navigate().back();
		
		
		
				
	}
}
