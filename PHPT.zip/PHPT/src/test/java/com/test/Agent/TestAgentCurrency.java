package com.test.Agent;

import org.testng.annotations.Test;

import com.pages.Agent.AgentCurrency;
import com.pages.Base.TestBase;

public class TestAgentCurrency extends TestBase{

	AgentCurrency objAgentCurr;
	@Test
	public void TestAgentCurr() throws Exception
	{
		objAgentCurr=new AgentCurrency(driver);
		Thread.sleep(2000);
		objAgentCurr.clickDropDown();
		Thread.sleep(2000);
		objAgentCurr.Clickrupee();
		Thread.sleep(2000);
	}
	
	
	
	
}
