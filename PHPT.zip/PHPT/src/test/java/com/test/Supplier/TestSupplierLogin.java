package com.test.Supplier;

import org.testng.annotations.Test;

import com.pages.Base.BaseSupplier;
import com.pages.Supplier.SupplierLogin;
import com.pages.utilities.ExcelUtility;

public class TestSupplierLogin extends BaseSupplier
{
SupplierLogin ObjLogin;
    
	@Test(priority=3)
		public void SupplierLog1() throws Exception
	{
		
		
		ObjLogin=new SupplierLogin(driver);
		driver.navigate().refresh();
		String email1 = ExcelUtility.getCellData(9, 0,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx",0);
		String password1= ExcelUtility.getCellData(9, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx",0);
		ObjLogin.setEmail(email1);
		ObjLogin.setPassword(password1);
		Thread.sleep(2000);
		ObjLogin.clickLogin();
		Thread.sleep(2000);
		
		
	}
	@Test(priority=2)
	public void SupplierLog2() throws Exception
	
	{
		ObjLogin=new SupplierLogin(driver);
		driver.navigate().refresh();
		String email2 = ExcelUtility.getCellData(10, 0,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx",0);
		String password2 = ExcelUtility.getCellData(10, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		ObjLogin.setEmail(email2);
		ObjLogin.setPassword(password2);
		Thread.sleep(2000);
		ObjLogin.clickLogin();
		Thread.sleep(2000);
	}
	@Test(priority=1)
    public void SupplierLog3() throws Exception
    {
    	ObjLogin=new SupplierLogin(driver);
		String email3 = ExcelUtility.getCellData(11, 0,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		String password3 = ExcelUtility.getCellData(11, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		ObjLogin.setEmail(email3);
		ObjLogin.setPassword(password3);
		Thread.sleep(2000);
		ObjLogin.clickLogin();
		Thread.sleep(2000);
    }
}
