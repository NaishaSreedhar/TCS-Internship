package com.test.Supplier;

import org.testng.annotations.Test;

import com.pages.Base.BaseSupplier;
import com.pages.Supplier.SupplierLogout;


public class TestSupplierLogout extends BaseSupplier{

	

	SupplierLogout ObjLogout;
	
	@Test
	public void LogoutAdmin() throws Exception
	{
		ObjLogout =new SupplierLogout(driver);
		ObjLogout.ClickIcon();
		Thread.sleep(2000);
		ObjLogout.Logout();
		
	}
	
}
