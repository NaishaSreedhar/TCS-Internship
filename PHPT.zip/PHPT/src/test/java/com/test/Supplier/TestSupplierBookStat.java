package com.test.Supplier;

import org.testng.annotations.Test;

import com.pages.Base.BaseSupplier;
import com.pages.Supplier.SupplierBookingStatus;


@Test
public class TestSupplierBookStat extends BaseSupplier {


	SupplierBookingStatus ObjChangeStat;
	
	
	@Test
	public void ChangeBookStat() throws Exception
	{
		ObjChangeStat=new SupplierBookingStatus(driver);
		ObjChangeStat.ClickPendBooking();
		Thread.sleep(2000);
		ObjChangeStat.ChangeStatus();
		Thread.sleep(2000);
		driver.navigate().back();
		Thread.sleep(2000);
		ObjChangeStat.CountConfirm();
		String confirm=ObjChangeStat.CountConfirm();
		System.out.println("confirm count is "+confirm);
		ObjChangeStat.CountPending();
		String pending=ObjChangeStat.CountPending();
		System.out.println("Pending count is "+pending);
		
	}
	
	
	
}
