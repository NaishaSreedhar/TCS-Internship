package com.test.Supplier;

import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import com.pages.Base.BaseSupplier;

import com.pages.Supplier.SupplierDisplayRevenue;

@Test
public class TestSupplierDisplayrev extends BaseSupplier

{

	SupplierDisplayRevenue objTextRV;

	@Test
	public void GetREvenueText() throws Exception {
		objTextRV = new SupplierDisplayRevenue(driver);
		Thread.sleep(2000);
		boolean display = objTextRV.isRevenuePresent();
		assertTrue(display);
		System.out.println(display);
	}
}
