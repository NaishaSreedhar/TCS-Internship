package com.test.Supplier;

import static org.testng.Assert.assertTrue;
import org.testng.annotations.Test;

import com.pages.Base.BaseSupplier;
import com.pages.Supplier.SupplierDashboardView;

@Test
public class TestSupplerDashboard extends BaseSupplier

{
	SupplierDashboardView objDbView;

	@Test
	public void TestDashboardLink() throws Exception {

		objDbView = new SupplierDashboardView(driver);
		Thread.sleep(2000);
		boolean dashboard = objDbView.isSalesTextPresent();
		assertTrue(dashboard);
		System.out.println(dashboard);
	}

}