package com.test.Supplier;

import org.testng.annotations.Test;
import com.pages.Base.BaseSupplier;
import com.pages.Supplier.SupplierLink;

public class TestSupplierLink extends BaseSupplier {

	SupplierLink ObjSupplierLink;

	@Test
	public void validatToursLink() throws Exception {

		ObjSupplierLink = new SupplierLink(driver);
		Thread.sleep(2000);
		ObjSupplierLink.toursLink();
		ObjSupplierLink.toursLink1();
		ObjSupplierLink.manageTours();
		Thread.sleep(2000);
		ObjSupplierLink.Booking();
		driver.navigate().back();

	}
}