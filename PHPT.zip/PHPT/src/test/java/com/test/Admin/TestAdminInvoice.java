package com.test.Admin;

import java.util.Iterator;
import java.util.Set;

import org.testng.annotations.Test;

import com.pages.Admin.AdminDisplayInvoice;
import com.pages.Base.BaseAdmin;

public class TestAdminInvoice extends BaseAdmin {

	
	AdminDisplayInvoice ObjInvoice;
	@Test
	public void DisplayInvoice() throws Exception
	{
		ObjInvoice =new AdminDisplayInvoice(driver);
		Thread.sleep(2000);
		ObjInvoice.ClickBooking();
		Thread.sleep(2000);
		ObjInvoice.Clickpaid();
		Thread.sleep(2000);
		ObjInvoice.ClickInvoice();
		Thread.sleep(6000);
		Set<String> windows=driver.getWindowHandles();
		Iterator<String>	It=windows.iterator();
			String parentId=It.next();
			driver.switchTo().window(parentId);
			
	}
	
	
	
	
}
