package com.test.Admin;

import org.testng.annotations.Test;

import com.pages.Admin.AdminLogout;
import com.pages.Base.BaseAdmin;

public class TestAdminLogout extends BaseAdmin {

	AdminLogout ObjLogout;
	
	@Test
	public void LogoutAdmin() throws Exception
	{
		ObjLogout =new AdminLogout(driver);
		ObjLogout.ClickIcon();
		Thread.sleep(2000);
		ObjLogout.Logout();
		
	}
	
	
}
