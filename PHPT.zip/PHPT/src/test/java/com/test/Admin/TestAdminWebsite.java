package com.test.Admin;

import java.util.Iterator;
import java.util.Set;

import org.testng.annotations.Test;

import com.pages.Admin.AdminWebsiteLink;
import com.pages.Base.BaseAdmin;

public class TestAdminWebsite extends BaseAdmin {

	AdminWebsiteLink ObjAdminWebsite;
	
	@Test
	public void ClickSite()
	{
		ObjAdminWebsite=new AdminWebsiteLink(driver);
		ObjAdminWebsite.ClickWebsite();
		 Set<String> windows=driver.getWindowHandles();
			Iterator<String>	It=windows.iterator();
				String parentId=It.next();
				driver.switchTo().window(parentId);
	}
	
}
