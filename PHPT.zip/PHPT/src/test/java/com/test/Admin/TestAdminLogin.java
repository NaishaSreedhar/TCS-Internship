package com.test.Admin;

import org.testng.annotations.Test;

import com.pages.Admin.AdminLogin;
import com.pages.Base.BaseAdmin;
import com.pages.utilities.ExcelUtility;

public class TestAdminLogin extends BaseAdmin{

	
AdminLogin ObjLogin;
    
	@Test(priority=3)
		public void AdminLog1() throws Exception
	{
		
		
		ObjLogin=new AdminLogin(driver);
		driver.navigate().refresh();
		String email1 = ExcelUtility.getCellData(6, 0,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx",0);
		String password1= ExcelUtility.getCellData(6, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx",0);
		ObjLogin.setEmail(email1);
		ObjLogin.setPassword(password1);
		Thread.sleep(2000);
		ObjLogin.clickLogin();
		Thread.sleep(2000);
		
	}
	@Test(priority=2)
	public void AdminLog2() throws Exception
	
	{
		ObjLogin=new AdminLogin(driver);
		driver.navigate().refresh();
		String email2 = ExcelUtility.getCellData(7, 0,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx",0);
		String password2 = ExcelUtility.getCellData(7, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		ObjLogin.setEmail(email2);
		ObjLogin.setPassword(password2);
		Thread.sleep(2000);
		ObjLogin.clickLogin();
		Thread.sleep(2000);
	}
	@Test(priority=1)
    public void AdminLog3() throws Exception
    {
    	ObjLogin=new AdminLogin(driver);
		String email3 = ExcelUtility.getCellData(8, 0,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		String password3 = ExcelUtility.getCellData(8, 1,System.getProperty("user.dir") + "\\src\\main\\resources\\ExcelUtility.xlsx", 0);
		ObjLogin.setEmail(email3);
		ObjLogin.setPassword(password3);
		Thread.sleep(2000);
		ObjLogin.clickLogin();
		Thread.sleep(2000);
    }
	
	
}


