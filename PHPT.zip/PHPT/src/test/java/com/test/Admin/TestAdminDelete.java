package com.test.Admin;


import org.testng.annotations.Test;
import com.pages.Admin.AdminDeleteRecord;
import com.pages.Base.BaseAdmin;

public class TestAdminDelete extends BaseAdmin{

	
	AdminDeleteRecord objAdminDelete;
	@Test
	public void AdminDelete() throws Exception
	{
		objAdminDelete=new AdminDeleteRecord(driver);
		objAdminDelete.CancelBooking();
		Thread.sleep(2000);
		objAdminDelete.DeleteStatus();
		Thread.sleep(3000);
		driver.switchTo().alert().accept();
	}
	
	
}
