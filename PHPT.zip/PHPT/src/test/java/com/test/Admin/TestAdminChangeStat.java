package com.test.Admin;

import org.testng.annotations.Test;

import com.pages.Admin.AdminBookingStatus;
import com.pages.Base.BaseAdmin;

public class TestAdminChangeStat extends BaseAdmin {

	
	AdminBookingStatus ObjChangeStat;
	
	
	@Test
	public void ChangeBookStat() throws Exception
	{
		ObjChangeStat=new AdminBookingStatus(driver);
		ObjChangeStat.ClickPendBooking();
		Thread.sleep(2000);
		ObjChangeStat.ChangeStatus();
		Thread.sleep(2000);
		ObjChangeStat.CountConfirm();
		String confirm=ObjChangeStat.CountConfirm();
		System.out.println("confirm count is "+confirm);
		ObjChangeStat.CountPending();
		String pending=ObjChangeStat.CountPending();
		System.out.println("Pending count is "+pending);
		
	}
	
}
